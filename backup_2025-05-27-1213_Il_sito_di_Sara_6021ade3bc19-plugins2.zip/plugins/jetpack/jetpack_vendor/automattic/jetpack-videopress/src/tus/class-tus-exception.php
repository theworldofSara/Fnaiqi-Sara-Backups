<?php
/**
 * Tus Exception
 *
 * @package jetpack-videopress
 */

namespace VideoPressUploader;

/**
 * Tus Exception
 */
class Tus_Exception extends \Exception {

}
