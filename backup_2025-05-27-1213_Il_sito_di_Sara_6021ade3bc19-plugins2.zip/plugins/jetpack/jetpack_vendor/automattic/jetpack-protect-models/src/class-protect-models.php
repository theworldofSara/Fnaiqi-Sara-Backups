<?php
/**
 * This package contains the models used in the Protect plugin.
 *
 * @package automattic/jetpack-protect-models
 */

namespace Automattic\Jetpack;

/**
 * Class description.
 */
class Protect_Models {

	const PACKAGE_VERSION = '0.5.5';
}
