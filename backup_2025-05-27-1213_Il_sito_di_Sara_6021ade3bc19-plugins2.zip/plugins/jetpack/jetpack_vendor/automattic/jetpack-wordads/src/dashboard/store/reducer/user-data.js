const userData = ( state = {} ) => {
	return state;
};

export default userData;
