const userDataSelectors = {
	getWpcomUser: state => state.userData?.currentUser?.wpcomUser,
};

export default userDataSelectors;
