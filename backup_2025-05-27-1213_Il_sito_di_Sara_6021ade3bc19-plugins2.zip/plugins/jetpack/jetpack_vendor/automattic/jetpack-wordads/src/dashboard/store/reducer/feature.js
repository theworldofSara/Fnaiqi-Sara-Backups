const features = ( state = [] ) => {
	return state;
};

export default features;
