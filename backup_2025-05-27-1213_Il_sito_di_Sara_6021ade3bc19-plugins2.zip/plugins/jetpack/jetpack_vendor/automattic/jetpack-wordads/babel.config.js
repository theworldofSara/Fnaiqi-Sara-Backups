module.exports = require( './tools/babel.config' );
