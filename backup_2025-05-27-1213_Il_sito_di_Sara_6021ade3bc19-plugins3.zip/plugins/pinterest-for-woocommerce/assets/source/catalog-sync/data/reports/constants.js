export const STORE_NAME = 'pinterest_for_woocommerce/admin/reports';
export const API_ROUTE = wcSettings.pinterest_for_woocommerce.apiRoute;
