export function getSetting() {
	return {
		es: 'Spain',
	};
}

export default getSetting;
