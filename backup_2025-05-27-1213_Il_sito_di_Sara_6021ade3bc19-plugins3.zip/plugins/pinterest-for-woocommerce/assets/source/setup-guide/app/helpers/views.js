export const SETTINGS_VIEW = 'settings';
