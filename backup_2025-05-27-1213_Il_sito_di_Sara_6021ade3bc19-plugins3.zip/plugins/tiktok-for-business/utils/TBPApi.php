<?php

/**
 * Abstract class used as enum to control TBP endpoint base url
 */
abstract class TBPApi {
	const TBP    = 0;
	const PLUGIN = 1;
}
